<?php


class FilterCarYear 
{
	
	
  public  static function getAll($from){	  
	  
	  $years = range($from, strftime("%Y", time())); 
	  
	  return $years;
	  
  } 
	
	
	
	
}

