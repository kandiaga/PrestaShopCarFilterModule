<?php



class FilterCarburant extends ObjectModel
{
	/** @var string Name */
	public $id;
	
	/** @var string Name */
	public $name;
	
	
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_carburant',
        'primary' => 'id_carburant',
        'multilang' => FALSE,
        'fields' => array(            		
            'name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),           		
			            	
        ),
    );    
	
	
	public static function loadById($id_carburant){
	 $id_lang = (int)Context::getContext()->language->id; 	 
	
	$sql = 'SELECT  name  FROM `'._DB_PREFIX_.'nsfilter_carburant` c    
	        WHERE  c.`id_carburant`='.(int)$id_carburant;
			
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['name']; 
	 
	 
	}
	
	
	public static function getAll()
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_carburant` 
		');
	}


	
	
	
	
}

