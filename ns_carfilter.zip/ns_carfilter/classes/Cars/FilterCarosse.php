<?php



class FilterCarosse extends ObjectModel
{
	/** @var string Name */
	public $id;
	
	/** @var string Name */
	public $name;
	
	public $id_carburant;
	
	public $id_motor_volume;
	
	public $id_hight_capacity;
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_carosse',
        'primary' => 'id_carosse',
        'multilang' => FALSE,
        'fields' => array(            		
            'name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),	
            'id_carburant' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 
            'id_motor_volume' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
            'id_hight_capacity' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),			
			            	
        ),
    );    
	
	
	
	public static function loadById($id_carosse){
	 $id_lang = (int)Context::getContext()->language->id; 	 
	
	$sql = 'SELECT  name  FROM `'._DB_PREFIX_.'nsfilter_carosse` ca   
	        WHERE  ca.`id_carosse`='.(int)$id_carosse;
			
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['name']; 
	 
	 
	}
	
	
	public static function getAll()
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_carosse` 
		');
	}

     public static function getByIdCapacity($id_hight_capacity)
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_carosse`   cr
			WHERE   cr.`id_hight_capacity`='.(int)$id_hight_capacity
		);
	}


 

	
	
	
	
	
}

