<?php


class FilterProduct extends ObjectModel
{
	/** @var string Name */
	public $id_nsfilter_product;
		
	/** @var integer */
	public $id_product;
	
	/** @var integer */
	public $id_marque;  
    public $id_model;
    public $id_carburant;
    public $id_motor_volume;
    public $id_hight_capacity;
    public $id_carosse;
    public $year_from;	
    public $year_to;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_product',
        'primary' => 'id_nsfilter_product',
        'multilang' => FALSE,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
            'id_marque' => array('type' => self::TYPE_HTML, 'validate' => 'isString'),
			'id_model' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'id_carburant' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'id_motor_volume' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'id_hight_capacity' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'id_carosse' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'year_from' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'year_to' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
        ),
    );
	
    public static function loadByIdProduct($id_product){
        $result = Db::getInstance()->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'nsfilter_product` sample
            WHERE sample.`id_product` = '.(int)$id_product
        );
        
        return new FilterProduct($result['id_nsfilter_product']);
    }
	
	
	public static function getAll()
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_product` 
		');
	}
	
	
	
		public function getResult($id_marque,$id_model=null,$id_carburant=null,$id_motor_volume=null,
		                          $id_hight_capacity=null,$id_carosse=null,$year_from=null)	
		{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		
		$results=array();
	
		 if(isset($id_marque) && $id_marque!='')	 
	 {				
    	
	
     $sql = 'SELECT  a.*, pl.name  AS `product_name`,pl.link_rewrite,a.`id_product`,p.`price` ,p.`reference`,p.`quantity`,
	         m.`model_name`,ma.`marque_name`,ca.`name` AS `carburant_name`,v.`name` AS `volume_name`,
			 hk.`name` AS `capacity_name`, cr.`name` AS `carosse_name`
         	 FROM `'._DB_PREFIX_.'nsfilter_product` a
			 LEFT JOIN `'._DB_PREFIX_.'nsfilter_models` m ON (m.`id_model`=a.`id_model`) 
			 LEFT JOIN `'._DB_PREFIX_.'nsfilter_marques` ma ON (ma.`id_marque`=a.`id_marque`) 
			 LEFT JOIN `'._DB_PREFIX_.'nsfilter_carburant` ca ON (ca.`id_carburant`=a.`id_carburant`) 
	         LEFT JOIN `'._DB_PREFIX_.'nsfilter_motor_volume` v ON (v.`id_motor_volume`=a.`id_motor_volume`) 
			 LEFT JOIN `'._DB_PREFIX_.'nsfilter_hight_capacity` hk ON (hk.`id_hight_capacity`=a.`id_hight_capacity`) 
			 LEFT JOIN `'._DB_PREFIX_.'nsfilter_carosse` cr ON (cr.`id_carosse`=a.`id_carosse`) 
			 LEFT JOIN `'._DB_PREFIX_.'product` p ON (p.`id_product`=a.`id_product`) 
			 LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (pl.`id_product`=p.`id_product`) '; 		 
	 $sql.=' WHERE  a.`id_marque`='.(int)$id_marque;
	 
	 
	 
	 if(isset($id_model)&& $id_model!='')	 
	 {       
	 $sql.='  AND  a.`id_model`='.(int)$id_model;
	 }
	 
	 
	 if(isset($id_carburant) && $id_carburant!='')	 
	 {	  	  
	   $sql.='  AND  a.`id_carburant`='.(int)$id_carburant;	 
	 }
	 
	 
	 if(isset($id_motor_volume) && $id_motor_volume!='')	 
	 {	  	  
	   $sql.='  AND  a.`id_motor_volume`='.(int)$id_motor_volume;	 
	 }
	 
	 if(isset($id_hight_capacity) && $id_hight_capacity!='')	 
	 {	  	  
	   $sql.='  AND  a.`id_hight_capacity`='.(int)$id_hight_capacity;	 
	 }
	 
	 if(isset($id_carosse) && $id_carosse!='')	 
	 {	  	  
	   $sql.='  AND  a.`id_carosse`='.(int)$id_carosse;	 
	 }
	 
	 
	 if(isset($year_from) && $year_from!='')	 
	 {	  	  
	   $sql.='  AND  a.`year_from`='.$year_from;	 
	 }
	
	$sql.='  AND pl.`id_lang`='.(int)$id_lang; 
	/*$sql.='  AND m.`id_lang`='.(int)$id_lang; 
	$sql.='  AND ma.`id_lang`='.(int)$id_lang; */
	
	$sql.=' ORDER BY  a.`id_nsfilter_product`  ASC  LIMIT  0,100';
	 
	 
	 $results = Db::getInstance()->ExecuteS($sql);
	  
	
     }	
		

		return $results;
		
	}
	
	
	
	
}

