<?php



class HightCapacity extends ObjectModel
{
	/** @var string Name */
	public $id;
	
	/** @var string Name */
	public $name;
	
	public $id_carburant;
	
	public $id_motor_volume;
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_hight_capacity',
        'primary' => 'id_hight_capacity',
        'multilang' => FALSE,
        'fields' => array(            		
            'name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),	
            'id_carburant' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 
            'id_motor_volume' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),			
			            	
        ),
    );    
	
	
	public static function loadById($id_hight_capacity){
	 $id_lang = (int)Context::getContext()->language->id; 	 
	
	$sql = 'SELECT  name  FROM `'._DB_PREFIX_.'nsfilter_hight_capacity` hk   
	        WHERE  hk.`id_hight_capacity`='.(int)$id_hight_capacity;
			
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['name']; 
	 
	 
	}
	
	
	
	
	public static function getAll()
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_hight_capacity` 
		');
	}
	
	
	 public static function getByIdVolume($id_motor_volume)
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_hight_capacity`   hk
			WHERE   hk.`id_motor_volume`='.(int)$id_motor_volume
		);
	}



 

	
	
	
	
	
}

