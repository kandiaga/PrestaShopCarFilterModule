<?php



class MotorVolume extends ObjectModel
{
	/** @var string Name */
	public $id;
	
	/** @var string Name */
	public $name;
	
	public $id_carburant;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_motor_volume',
        'primary' => 'id_motor_volume',
        'multilang' => FALSE,
        'fields' => array(            		
            'name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),	
            'id_carburant' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 			
			            	
        ),
    );    
	
	
	
	public static function loadById($id_motor_volume){
	 $id_lang = (int)Context::getContext()->language->id; 	 
	
	$sql = 'SELECT  name  FROM `'._DB_PREFIX_.'nsfilter_motor_volume` v    
	        WHERE  v.`id_motor_volume`='.(int)$id_motor_volume;
			
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['name']; 
	 
	 
	}
	
	
	public static function getAll()
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_motor_volume` 
		');
	}



   public static function getByIdCarburant($id_carburant)
	{
		return Db::getInstance()->ExecuteS('
			SELECT *
			FROM `'._DB_PREFIX_.'nsfilter_motor_volume`   v
			WHERE   v.`id_carburant`='.(int)$id_carburant
		);
	}


 

	
	
	
	
	
}

