<?php



class FilterMarques extends ObjectModel
{
	/** @var string Name */
	public $id_marque;
	/** @var string Name */
	public $category_id;
	
	/** @var string Name */
	public $marque_name;
	
	public $more_infos;
	
	public $id_lang;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_marques',
        'primary' => 'id_marque',
        'multilang' => FALSE,
        'fields' => array(            		
            'marque_name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),	
            'category_id' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 
			'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 	
            'more_infos' => array('type' => self::TYPE_HTML, 'validate' => 'isString'),			
			            	
        ),
    );    
	
	public static function loadById($id_marque){
	 $id_lang = (int)Context::getContext()->language->id; 	
	 
	
	$sql = 'SELECT  q.`marque_name`  FROM `'._DB_PREFIX_.'nsfilter_marques` q    
	        WHERE  q.`id_marque`='.(int)$id_marque.'
			AND q.id_lang='.(int)$id_lang;	
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['marque_name'];
	
	
	}
		
		
	
	public static function loadByIdCategory($category_id){
	
	$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_marques` q    
	        WHERE  q.`category_id`='.(int)$category_id;	
    $result= Db::getInstance()->getRow($sql);	
	
	return new FilterMarques($result['id_marque']);
	
	
	}
	
	
	public static function getMarques()
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_marques` a   
	         ORDER BY a.`id_marque`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}	
	
	
	
	
	
	public function getAnswers($id_marque)
	{
	    
	    //$id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_models` a   
	        WHERE  a.`id_marque`='.$id_marque.' ORDER BY a.`id_answer`  ASC';	
    $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}	
	
	
	
	
	
	//verify duplicated cards number
	
	public static function verifyByName($query)
	{
		return Db::getInstance()->getRow('
			SELECT iv.`id_marque`
			FROM `'._DB_PREFIX_.'nsfilter_marques` iv			
			WHERE iv.`marque_name` LIKE \''.pSQL($query).'\'
		');
	}

	
	

	
	
	
	
}

