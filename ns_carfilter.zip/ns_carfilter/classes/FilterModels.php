<?php



class FilterModels extends ObjectModel
{
	/** @var string Name */
	public $id_model;
	/** @var string Name */
	public $id_marque;	
	
	/** @var string Name */
	public $id_lang;
	
	/** @var string Name */
	public $model_name;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_models',
        'primary' => 'id_model',
        'multilang' => FALSE,
        'fields' => array(            		
            'model_name'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'id_marque' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 
            'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),			
			            	
        ),
    );    
	
	
		
	
	public static function loadById($id_model){
	 $id_lang = (int)Context::getContext()->language->id; 	
	 
	
	$sql = 'SELECT  model_name  FROM `'._DB_PREFIX_.'nsfilter_models` q    
	        WHERE  q.`id_model`='.(int)$id_model
			 ;	
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['model_name'];
	
	 
	 
	 
	}
	
	
	
	public static function getModels()
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_models` m   
	        WHERE  m.`id_lang`='.$id_lang.' ORDER BY m.`id_model`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}


   public static function getModelsByIdMake($id_marque)
	{
	    
		if($id_marque!='') {
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_models` m   
	        WHERE  m.`id_marque`='.$id_marque.' 
			  AND   m.`id_lang`='.(int)$id_lang.'  
			  ORDER BY m.`id_model`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
		}
		
	}		
	
	
	
	//verify duplicated cards number
	
	public static function verifyByName($query)
	{
		return Db::getInstance()->getRow('
			SELECT iv.`model`
			FROM `'._DB_PREFIX_.'nsfilter_models` iv			
			WHERE iv.`answer_name` LIKE \''.pSQL($query).'\'
		');
	}
	
	
	// get all answers
	
	
    public static function getAnswersByQuestion($id_question)
	{
	    
	    //$id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_models` a   
	        WHERE  a.`id_marque`='.$id_question.' ORDER BY a.`model`  ASC';	
    $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}	
	
	

	    public static function getFeatureProducts($id_feature_value){	
		$id_lang = (int)Context::getContext()->language->id;	
		
		$results =Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(' 
		SELECT * FROM '._DB_PREFIX_.'feature_product pf	                       
		INNER JOIN `'._DB_PREFIX_.'feature_value` f ON (f.`id_feature_value` = pf.`id_feature_value`)							
		INNER JOIN  `'._DB_PREFIX_.'product` p ON p.`id_product`=pf.`id_product`	
		INNER JOIN  `'._DB_PREFIX_.'product_lang` pl ON pl.`id_product`=p.`id_product`	   
		LEFT JOIN `'._DB_PREFIX_.'image` i	ON (i.`id_product` = pl.`id_product`)						                       
		WHERE pf.id_feature_value = '.(int)$id_feature_value.'		
		AND  pl.id_lang='.$id_lang                            
		);		
		return $results;				
		} 
	
	
	
}

