<?php



class FilterOils extends ObjectModel
{
	/** @var string Name */	
	public $id_oil;  
    public $id_lang;  
    public $make;
    public $model;	
    public $type;	
    public $componentName;	
    public $componentCode;	
    public $capacities;
    public $DryCapacityBottles;
    public $SmallBottleRef;	
    public $GallonBottleReference;
    public $OilDesignation;
    public $OilLinkSmallBottle;
    public $OilLinkGallonBottle;
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_oils',
        'primary' => 'id_oil',
        'multilang' => FALSE,
        'fields' => array(                     
            'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
            'make'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'model'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'type'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),
            'componentName'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'componentCode'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'capacities'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	 
            'DryCapacityBottles'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'SmallBottleRef'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'GallonBottleReference'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	 
            'OilDesignation'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'OilLinkSmallBottle'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),	
            'OilLinkGallonBottle'=>array('type' =>self::TYPE_HTML, 'validate' => 'isString', 'required' => true, 'size' => 228),           			
			            	
        ),
    );    
	
	
		
	
	
	public static function getOils()
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_oils` t   
	        WHERE  t.`id_lang`='.$id_lang.' ORDER BY t.`id_oil`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}
	
	
	public static function getModelsByIdMake($id_marque)
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  DISTINCT  t.`model`  AS `id_model` FROM `'._DB_PREFIX_.'nsfilter_oils` t                 	
	           WHERE  t.`make`='.(int)$id_marque;
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}		


  public static function getTypesByIdModel($id_model)
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  DISTINCT  t.`type` AS `id_type` FROM `'._DB_PREFIX_.'nsfilter_oils` t                 	
	           WHERE  t.`model`='.(int)$id_model;
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}		
	
	
	public function getResult($id_marque,$id_model=null,$id_type=null)	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		
		$results=array();
	
		 if(isset($id_marque) && $id_marque!='')	 
	 {				
    	
	
     $sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_oils` a  '; 		 
	 $sql.=' WHERE  a.`make`='.(int)$id_marque;
	 
	 
	 
	 if(isset($id_model)&& $id_model!='')	 
	 {       
	 $sql.='  AND  a.`model`='.(int)$id_model;
	 }
	 
	 
	 if(isset($id_type) && $id_type!='')	 
	 {	  	  
	   $sql.='  AND  a.`type`='.(int)$id_type;	 
	 }
	 
	
	/*$sql.='  AND a.id_lang='.(int)$id_lang; */
	
	$sql.=' ORDER BY  a.`id_oil`  ASC  LIMIT  0,100';
	 
	 
	 $results = Db::getInstance()->ExecuteS($sql);
	  
	
     }	
		

		return $results;
		
	}	
	
	
	//verify duplicated cards number
	
	public static function verifyByName($query)
	{
		return Db::getInstance()->getRow('
			SELECT iv.`model`
			FROM `'._DB_PREFIX_.'nsfilter_oils` iv			
			WHERE iv.`answer_name` LIKE \''.pSQL($query).'\'
		');
	}
	
	
	

	    public static function getFeatureProducts($id_feature_value){	
		$id_lang = (int)Context::getContext()->language->id;	
		
		$results =Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(' 
		SELECT * FROM '._DB_PREFIX_.'feature_product pf	                       
		INNER JOIN `'._DB_PREFIX_.'feature_value` f ON (f.`id_feature_value` = pf.`id_feature_value`)							
		INNER JOIN  `'._DB_PREFIX_.'product` p ON p.`id_product`=pf.`id_product`	
		INNER JOIN  `'._DB_PREFIX_.'product_lang` pl ON pl.`id_product`=p.`id_product`	   
		LEFT JOIN `'._DB_PREFIX_.'image` i	ON (i.`id_product` = pl.`id_product`)						                       
		WHERE pf.id_feature_value = '.(int)$id_feature_value.'		
		AND  pl.id_lang='.$id_lang                            
		);		
		return $results;				
		} 
		
		
		public static function getComponents($Components_ID)
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_components` c
		       WHERE c.`Components_ID`='.(int)$Components_ID;
			
       $results = Db::getInstance()->getRow($sql);
		
		

		return $results;
		
	}
	
	
		public static function getCapacity($DryCapacity_ID)
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_drycapacity` c
		       WHERE c.`DryCapacity_ID`='.(int)$DryCapacity_ID;
			
       $results = Db::getInstance()->getRow($sql);
		
		

		return $results;
		
	}
	
	
	
}

