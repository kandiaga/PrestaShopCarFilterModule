<?php



class ModelTypes extends ObjectModel
{
	/** @var string Name */
	public $id_type;
	/** @var string Name */
	public $id_model;	
	
	/** @var string Name */
	public $id_lang;
	
	/** @var string Name */
	public $name;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'nsfilter_types',
        'primary' => 'id_type',
        'multilang' => FALSE,
        'fields' => array(            		
            'type_name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),	
            'id_model' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE), 
            'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),			
			            	
        ),
    );    
	
	
	
	public static function loadById($id_type){
	 $id_lang = (int)Context::getContext()->language->id; 	
	
	$sql = 'SELECT  type_name  FROM `'._DB_PREFIX_.'nsfilter_types` q    
	        WHERE  q.`id_type`='.(int)$id_type
			  ;	
    $result= Db::getInstance()->getRow($sql);	
	
	return $result['type_name'];
	
	
	}
	
	
	public static function loadByIdQuestion($id_model){
	
	$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_types` q    
	        WHERE  q.`id_marque`='.$id_marque;	
    $result= Db::getInstance()->getRow($sql);	
	
	return new ModelTypes($result['id_model']);
	
	
	}
	
	
	public static function getTypes()
	{
	    
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_types` t   
	        WHERE  t.`id_lang`='.$id_lang.' ORDER BY t.`id_type`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}	
	
	
	public static function getTypesByIdModel($id_model)
	{
	    
		if($id_model!='') {
	    $id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_types` m   
	        WHERE  m.`id_model`='.(int)$id_model.' 
			  AND   m.`id_lang`='.(int)$id_lang.'  
			  ORDER BY m.`id_type`  ASC';
			
       $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
		}
		
	}		
	
	
	//verify duplicated cards number
	
	public static function verifyByName($query)
	{
		return Db::getInstance()->getRow('
			SELECT iv.`model`
			FROM `'._DB_PREFIX_.'nsfilter_types` iv			
			WHERE iv.`answer_name` LIKE \''.pSQL($query).'\'
		');
	}
	
	
	// get all answers
	
	
    public static function getAnswersByQuestion($id_question)
	{
	    
	    //$id_lang = (int)Context::getContext()->language->id; 
		$sql = 'SELECT  * FROM `'._DB_PREFIX_.'nsfilter_types` a   
	        WHERE  a.`id_marque`='.$id_question.' ORDER BY a.`model`  ASC';	
    $results = Db::getInstance()->ExecuteS($sql);
		
		

		return $results;
		
	}	
	
	

	    public static function getFeatureProducts($id_feature_value){	
		$id_lang = (int)Context::getContext()->language->id;	
		
		$results =Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(' 
		SELECT * FROM '._DB_PREFIX_.'feature_product pf	                       
		INNER JOIN `'._DB_PREFIX_.'feature_value` f ON (f.`id_feature_value` = pf.`id_feature_value`)							
		INNER JOIN  `'._DB_PREFIX_.'product` p ON p.`id_product`=pf.`id_product`	
		INNER JOIN  `'._DB_PREFIX_.'product_lang` pl ON pl.`id_product`=p.`id_product`	   
		LEFT JOIN `'._DB_PREFIX_.'image` i	ON (i.`id_product` = pl.`id_product`)						                       
		WHERE pf.id_feature_value = '.(int)$id_feature_value.'		
		AND  pl.id_lang='.$id_lang                            
		);		
		return $results;				
		} 
	
	
	
}

