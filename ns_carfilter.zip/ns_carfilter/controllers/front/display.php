<?php
if (!defined('_PS_VERSION_'))
 exit; 
class  ns_carfilterdisplayModuleFrontController extends ModuleFrontController
{
	  
  public function initContent()
	  {
	  
	     $this->display_column_left =false;
         $this->display_column_right =false;
		
		
		parent::initContent();		
		
		$id_lang = (int)Context::getContext()->language->id;
		
		$quiz=new Filter();		
		$categories=Filter::getAllCategories($id_lang);
		
		
		
		$ps_version=_PS_VERSION_;		
		$base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 
       
        $template_path='module:'.$this->module->name;	
		
        $id_category=(int)Tools::getValue('id_category')?(int)Tools::getValue('id_category'):'';	
        $id_marque=(int)Tools::getValue('id_marque')?(int)Tools::getValue('id_marque'):'';	
        $id_model=(int)Tools::getValue('id_model')?(int)Tools::getValue('id_model'):'';		
		$id_type=(int)Tools::getValue('id_type')?(int)Tools::getValue('id_type'):'';	
		$id_carburant=(int)Tools::getValue('id_carburant')?(int)Tools::getValue('id_carburant'):'';
		$id_motor_volume=(int)Tools::getValue('id_motor_volume')?(int)Tools::getValue('id_motor_volume'):'';
		$id_hight_capacity=(int)Tools::getValue('id_hight_capacity')?(int)Tools::getValue('id_hight_capacity'):'';
		$id_carosse=(int)Tools::getValue('id_carosse')?(int)Tools::getValue('id_carosse'):'';
		$year_from=Tools::getValue('year_from')?(int)Tools::getValue('year_from'):'';
		$year_to=Tools::getValue('year_to')?(int)Tools::getValue('year_to'):'';
		
		$id_product=(int)Tools::getValue('idp')?(int)Tools::getValue('idp'):'';
		
		$year_start=2000;
		$year_second_start=Tools::getValue('year_from');

      /* $all_models=FilterModels::getModelsByIdMake($id_marque);	*/	
	  $all_models=FilterOils::getModelsByIdMake($id_marque);

     	$iso_code=Context::getContext()->language->iso_code;  
		
		$id_feature_value=Tools::getValue('id_fvalue');
		$this->context->smarty->assign(array(
		'logged' => $this->context->customer->isLogged(),
		'customerName' => ($this->context->customer->logged ? $this->context->customer->firstname.' '.$this->context->customer->lastname : false),
		'firstName' => ($this->context->customer->logged ? $this->context->customer->firstname : false),
		'lastName' => ($this->context->customer->logged ? $this->context->customer->lastname : false),		
		'nka_display_link' => $this->context->link->getModuleLink('ns_carfilter', 'display'),
		'result_submit_link' => $this->context->link->getModuleLink('ns_carfilter', 'display'),        
        'categories'=>$categories,	 		
        'allow_oosp' => (int)Configuration::get('PS_ORDER_OUT_OF_STOCK'),
		'comparator_max_item' => (int)Configuration::get('PS_COMPARATOR_MAX_ITEM'),	
        'add_prod_display' => Configuration::get('PS_ATTRIBUTE_CATEGORY_DISPLAY'),
		'categorySize' => Image::getSize(ImageType::getFormatedName('category')),
		'mediumSize' => Image::getSize(ImageType::getFormatedName('medium')),
		'thumbSceneSize' => Image::getSize(ImageType::getFormatedName('m_scene')),
		'homeSize' => Image::getSize(ImageType::getFormatedName('home')),        	
        'id_fvalue'=>$id_feature_value,
        'all_models'=> $all_models,
        'all_makes' =>FilterMarques::getMarques(),
        'all_types'=>FilterOils::getTypesByIdModel($id_model),		
        'id_customer'=> ($this->context->customer->logged ? $this->context->customer->id: false),
        //'products'=>FilterAnswers::getFeatureProducts($id_feature_value),	
       'base_dir_nka'=>$base_dir_nka, 	
      'middlePosition'=>6,	
      'template_path'=>$template_path,
      'id_category'=>$id_category,	  
	  'id_marque'=>$id_marque,
      'id_model'=>$id_model,
      'id_type'=>$id_type,
	  'id_carburant'=>$id_carburant,
	  'id_motor_volume'=>$id_motor_volume,
	  'id_hight_capacity'=>$id_hight_capacity,
	  'id_carosse'=>$id_carosse,      
	  'id_lang'=>$id_lang,
	  'nka_lang'=>Context::getContext()->language,
	  'iso_code'=>$iso_code,
	  'all_model_carburants'=>FilterCarburant::getByIdModel($id_model),
	  'all_motor_volumes'=>MotorVolume::getByIdCarburant($id_carburant),
	  'all_hight_capacities'=>HightCapacity::getByIdVolume($id_motor_volume),
	  'all_carosses'=>FilterCarosse::getByIdCapacity($id_carburant,$id_motor_volume,$id_hight_capacity),
	  'all_years_start'=>FilterCarYear::getAll($year_start),
	  'all_years_to'=>FilterCarYear::getAll($year_second_start),
	  'year_from'=>$year_from,
	  'year_to'=>$year_to,
	  'id_product'=>$id_product,
	  
      
        
	));
		
		
		  $template='module:'.$this->module->name.'/views/templates/front/display.tpl';	
		   $this->setTemplate($template); 		
		
		
		  
	  }
	  
	  
	  
	  
	  public  function saveData($id_product){
		  
		  
		  if(Tools::isSubmit('SubmitSaveSelected') &&  !empty($id_product)){
			  
		$sampleObj = FilterProduct::loadByIdProduct($id_product);        
        $sampleObj->id_product = $id_product;
		$sampleObj->id_marque= Tools::getValue('id_marque'); 
        $sampleObj->id_model= Tools::getValue('id_model');
        $sampleObj->id_carburant= Tools::getValue('id_carburant');
        $sampleObj->id_motor_volume= Tools::getValue('id_motor_volume');
        $sampleObj->id_hight_capacity= 11; //Tools::getValue('id_hight_capacity');
        $sampleObj->id_carosse= 12;//Tools::getValue('id_carosse');
        $sampleObj->year_from= Tools::getValue('year_from');
        $sampleObj->year_to= Tools::getValue('year_from');
        
        if(!empty($sampleObj) && isset($sampleObj->id)){
            $sampleObj->update();
        } else {
            $sampleObj->add();
        }
			  
			  
		  }
		  
		  
		  
	  }
    


}

