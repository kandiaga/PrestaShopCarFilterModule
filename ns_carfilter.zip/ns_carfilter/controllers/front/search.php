<?php
if (!defined('_PS_VERSION_'))
 exit; 


class  ns_carfiltersearchModuleFrontController  extends  ModuleFrontController
{
	  public function initContent()
	  {
	  
	     $this->display_column_left =false;
         $this->display_column_right =false;
		
		
		parent::initContent();		
		
		$id_lang = (int)Context::getContext()->language->id;
		
		$quiz=new Filter();		
		$categories=Filter::getAllCategories($id_lang);
		
		
		
		$ps_version=_PS_VERSION_;		
		$base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 
       
        $template_path='module:'.$this->module->name;

        		
		
        $id_category=(int)Tools::getValue('id_category')?(int)Tools::getValue('id_category'):'';	
        $id_marque=(int)Tools::getValue('id_marque')?(int)Tools::getValue('id_marque'):'';	
        $id_model=(int)Tools::getValue('id_model')?(int)Tools::getValue('id_model'):'';		
		$id_type=(int)Tools::getValue('id_type')?(int)Tools::getValue('id_type'):'';	
		$id_carburant=(int)Tools::getValue('id_carburant')?(int)Tools::getValue('id_carburant'):'';
		$id_motor_volume=(int)Tools::getValue('id_motor_volume')?(int)Tools::getValue('id_motor_volume'):'';
		$id_hight_capacity=(int)Tools::getValue('id_hight_capacity')?(int)Tools::getValue('id_hight_capacity'):'';
		$id_carosse=(int)Tools::getValue('id_carosse')?(int)Tools::getValue('id_carosse'):'';
		$year_from=Tools::getValue('year_from')?(int)Tools::getValue('year_from'):'';
		$year_to=Tools::getValue('year_to')?(int)Tools::getValue('year_to'):'';
		
		$year_start=2000;
		$year_second_start=Tools::getValue('year_from');

       $all_models=FilterModels::getModelsByIdMake($id_marque);		
	  

     	$iso_code=Context::getContext()->language->iso_code;  
		
	  $all_products=$this->getSearch($id_marque,$id_model,$id_carburant,$id_motor_volume,$id_hight_capacity,$id_carosse,$year_from);
		
		$id_feature_value=Tools::getValue('id_fvalue');
		$this->context->smarty->assign(array(
		'logged' => $this->context->customer->isLogged(),
		'customerName' => ($this->context->customer->logged ? $this->context->customer->firstname.' '.$this->context->customer->lastname : false),
		'firstName' => ($this->context->customer->logged ? $this->context->customer->firstname : false),
		'lastName' => ($this->context->customer->logged ? $this->context->customer->lastname : false),		
		'nka_add_voucher_submit_link' => $this->context->link->getModuleLink('ns_carfilter', 'search'),
		'result_submit_link' => $this->context->link->getModuleLink('ns_carfilter', 'search'),        
        'categories'=>$categories,	 		
        'allow_oosp' => (int)Configuration::get('PS_ORDER_OUT_OF_STOCK'),
		'comparator_max_item' => (int)Configuration::get('PS_COMPARATOR_MAX_ITEM'),	
        'add_prod_display' => Configuration::get('PS_ATTRIBUTE_CATEGORY_DISPLAY'),
		'categorySize' => Image::getSize(ImageType::getFormatedName('category')),
		'mediumSize' => Image::getSize(ImageType::getFormatedName('medium')),
		'thumbSceneSize' => Image::getSize(ImageType::getFormatedName('m_scene')),
		'homeSize' => Image::getSize(ImageType::getFormatedName('home')),        	
        'id_fvalue'=>$id_feature_value,
        'all_models'=> $all_models,
        'all_makes' =>FilterMarques::getMarques(),
        'all_types'=>FilterOils::getTypesByIdModel($id_model),		
        'id_customer'=> ($this->context->customer->logged ? $this->context->customer->id: false),
        //'products'=>FilterAnswers::getFeatureProducts($id_feature_value),	
       'base_dir_nka'=>$base_dir_nka, 	
      'middlePosition'=>6,	
      'template_path'=>$template_path,
      'module_path'=>Module::getInstanceByname('ns_carfilter')->getPath(),	  
      'id_category'=>$id_category,	  
	  'id_marque'=>$id_marque,
      'id_model'=>$id_model,
      'id_type'=>$id_type,
	  'id_carburant'=>$id_carburant,
	  'id_motor_volume'=>$id_motor_volume,
	  'id_hight_capacity'=>$id_hight_capacity,
	  'id_carosse'=>$id_carosse,
      'all_products'=>$all_products,
	  'id_lang'=>$id_lang,
	  'nka_lang'=>Context::getContext()->language,
	  'iso_code'=>$iso_code,
	  'all_model_carburants'=>FilterCarburant::getAll(),
	  'all_motor_volumes'=>MotorVolume::getByIdCarburant($id_carburant),
	  'all_hight_capacities'=>HightCapacity::getByIdVolume($id_motor_volume),
	  'all_carosses'=>FilterCarosse::getByIdCapacity($id_hight_capacity),
	  'all_years_start'=>FilterCarYear::getAll($year_start),
	  'all_years_to'=>FilterCarYear::getAll($year_second_start),
	  'year_from'=>$year_from,
	  'year_to'=>$year_to,
	  
      
        
	));
		
		
		  $template='module:'.$this->module->name.'/views/templates/front/ns_search.tpl';	
		   $this->setTemplate($template); 		
		
    }		
	 
   
	
	public function setMedia()
	{
		parent::setMedia();
		$this->addCSS(array(
				_THEME_CSS_DIR_.'scenes.css' => 'all',
				_THEME_CSS_DIR_.'category.css' => 'all',
				_THEME_CSS_DIR_.'product_list.css' => 'all',
			));
		
		$this->addJS(_THEME_JS_DIR_.'scenes.js');
		$this->addJqueryPlugin(array('scrollTo', 'serialScroll'));
		$this->addJS(_THEME_JS_DIR_.'category.js');
	}

	
	
	public  function getSearch($id_marque,$id_model,$id_carburant,$id_motor_volume,$id_hight_capacity,$id_carosse,$year_from)
	{
	 	if(Tools::isSubmit('SubmitSearch') && !empty($id_marque) && !empty($id_model) && !empty($year_from)){
	$searchResults=FilterProduct::getResult($id_marque,$id_model,$id_carburant,$id_motor_volume,$id_hight_capacity,$id_carosse,$year_from);	
	
	
	  return  $searchResults;

		}
	}
	
    


}//end of class

