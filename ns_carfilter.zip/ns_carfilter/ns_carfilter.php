<?php
if (!defined('_PS_VERSION_')){
  exit;
 } 
 
require_once(dirname(__FILE__) . '/classes/Filter.php');  
require_once(dirname(__FILE__) . '/classes/FilterMarques.php');  
require_once(dirname(__FILE__) . '/classes/FilterModels.php');  
require_once(dirname(__FILE__) . '/classes/ModelTypes.php');  
require_once(dirname(__FILE__) . '/classes/FilterOils.php');  

/* New   Classes */

require_once(dirname(__FILE__) . '/classes/Cars/FilterCarburant.php'); 
require_once(dirname(__FILE__) . '/classes/Cars/MotorVolume.php'); 
require_once(dirname(__FILE__) . '/classes/Cars/HightCapacity.php'); 
require_once(dirname(__FILE__) . '/classes/Cars/FilterCarosse.php'); 
require_once(dirname(__FILE__) . '/classes/Cars/FilterCarYear.php'); 

require_once(dirname(__FILE__) . '/classes/Cars/FilterProduct.php'); 






  class ns_carfilter  extends Module
  
  { 
  
  public function __construct()
  {
    $this->name = 'ns_carfilter';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'NdiagaSoft';
    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' =>_PS_VERSION_);
    $this->bootstrap = true;
 
    parent::__construct();
 
    $this->displayName = $this->l('Car Filter');
    $this->description = $this->l('A car Filter in your Shop .');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); 
    
  }
  
  
  public function install()
{
  if (Shop::isFeatureActive())
    Shop::setContext(Shop::CONTEXT_ALL); 
  if (!parent::install() ||
    !$this->registerHook('DisplayNav') ||	
	!$this->registerHook('displayTopColumn')||
	!$this->registerHook('myAccountBlock')|| 
	!$this->registerHook('customerAccount')||    		 
    !$this->registerHook('productFooter') ||
	!$this->registerHook('displayAdminProductsExtra') || 
    !$this->registerHook('actionProductUpdate') || 
    !$this->registerHook('shoppingCart')||
	!$this->registerHook('DisplayshoppingCart')|| 
    !$this->registerHook('adminOrder')||
    !$this->registerHook('displayTop')||	
    !$this->registerHook('header')||    
    !Configuration::updateValue('DEFAULT_PROD_ID',1) 	
  )
    return false;
	
	
	$sql = array();
        require_once(dirname(__FILE__) . '/sql/install.php');
        foreach ($sql as $sq) :
            if (!Db::getInstance()->Execute($sq))
                return false;
        endforeach;
		
  
  return true;
}
       public function uninstall()
    {      
		
		if (!parent::uninstall()||
		    
            !Configuration::deleteByName('DEFAULT_PROD_ID')				
           )
                return false;  	
    			
     $sql = array();
        require_once(dirname(__FILE__) . '/sql/uninstall.php');
        foreach ($sql as $s) :
            if (!Db::getInstance()->Execute($s))
                return false;
        endforeach;		
				
           return true;
    }  
  
        public function getContent()
    {
          
		  $output = null;
		  
		 $output .= $this->addMenu();
		  
		 
		 
		 
		 
		 
		$search_link=$this->context->link->getModuleLink('ns_carfilter', 'search');	
		  
		    if (Tools::isSubmit('submit'.$this->name))
      {
        $my_module_name =Tools::getValue('id_product');
        if (!$my_module_name || empty($my_module_name) || !Validate::isGenericName($my_module_name))
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {
		   
				
		    
            Configuration::updateValue('DEFAULT_PROD_ID',(int)$my_module_name);
		
            $output.= $this->displayConfirmation($this->l('Settings updated'));
        }
      }
		  
		   if (Tools::isSubmit('deletemotor_volume') && Tools::isSubmit('id_motor_volume')!='')
		{
		 $MotorVolume=new MotorVolume((int)Tools::getValue('id_motor_volume'));
         $MotorVolume->delete();	
         $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));	   
		} 
		
		  if (Tools::isSubmit('deletensfilter_carburant') && Tools::isSubmit('id_carburant')!='')
		{
		 $FilterCarburant=new FilterCarburant((int)Tools::getValue('id_carburant'));
         $FilterCarburant->delete();	
         $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));	   
		} 
		
		  if (Tools::isSubmit('deletensfilter_capacity') && Tools::isSubmit('id_hight_capacity')!='')
		{
		 $HightCapacity=new HightCapacity((int)Tools::getValue('id_hight_capacity'));
         $HightCapacity->delete();	
         $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));	   
		} 
		
		  if (Tools::isSubmit('deletensfilter_carosse') && Tools::isSubmit('id_carosse')!='')
		{
		 $FilterCarosse=new FilterCarosse((int)Tools::getValue('id_carosse'));
         $FilterCarosse->delete();	
         $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));	   
		} 
		
		
		
		
		

          if (Tools::isSubmit('deletensfilter_categories') && Tools::isSubmit('id'))
		{
		 $quizCat=new Filter((int)Tools::getValue('id'));
         $quizCat->delete();	
		 $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));
               		   
		} 		
		
		
		   if (Tools::isSubmit('deletensfilter_marques') && Tools::isSubmit('id_marque'))
		{
		 $FilterMarques=new FilterMarques((int)Tools::getValue('id_marque'));
         $FilterMarques->delete();	
		 $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));
               		   
		} 
		
		 		
		
         
           elseif (Tools::isSubmit('updatesimplequiz_categories') && Tools::isSubmit('id'))
		{
		 
		 //$output.=$this->renderUpdate();
		
               	 
		}  		  
		elseif (Tools::isSubmit('viewnsfilter_categories') && Tools::isSubmit('id'))
		{
		   
		$output.=$this->renderCategoryItems();	
        	
		}

        elseif (Tools::isSubmit('viewAddNewCategory')  || Tools::isSubmit('submitAddnewCategory'))
		{
			
			if(Tools::isSubmit('submitAddnewCategory')  && Tools::getValue('id_lang')!=''){
		      $this->addnewCategory();	
		   	}  
			
		   $output.='</br>'.$this->renderAddNewCategoryForm().'</br>'.$this->renderList();
           
		
		}
		
		elseif (Tools::isSubmit('viewAddNewMake')  || Tools::isSubmit('submitAddnewMake'))
		{
		       
			   if(Tools::isSubmit('submitAddnewMake')){
		             $output.=$this->addnewMake();	
              }		   
           $output.=$this->renderCategoryItems();
		
		 }
		 
		 /* Filter Models   */
		 elseif (Tools::isSubmit('viewAddNewModel')  || Tools::isSubmit('submitAddNewModel'))
		{
		       
			   if(Tools::isSubmit('submitAddNewModel')){
		             $this->addnewModel();	  
              }	

              
		
		     if (Tools::isSubmit('deletensfilter_models') && Tools::isSubmit('id_model') !='')
		    {
		      $FilterModels=new FilterModels((int)Tools::getValue('id_model'));
              $FilterModels->delete();	
			  $output.= $this->displayConfirmation($this->l('Item Removed Successfully.'));
               		   
		     }    
             			  
           $output.=$this->renderModelItems();
		
		 }

       /* Filter Types   */
		 elseif (Tools::isSubmit('viewAddNewVolume')  || Tools::isSubmit('submitAddnewVolume'))
		{
			if(Tools::isSubmit('submitAddnewVolume')){
		             $output.=$this->addnewVolume();	  
              }	
			
			$output.=$this->renderVolumeItems();
	    }		 
		 
		/*  List  Capacities*/ 
		 
		 
		  elseif (Tools::isSubmit('viewCapacities')  || Tools::isSubmit('submitAddnewCapacity'))
		{
			if(Tools::isSubmit('submitAddnewCapacity')){
		             $output.=$this->addnewCapacity();	  
              }	
			
			$output.=$this->renderListCapacities();
	    }
		
		
				  elseif (Tools::isSubmit('viewAddNewCarburant')  || Tools::isSubmit('submitAddnewCarburant'))
		{
			if(Tools::isSubmit('submitAddnewCarburant')){
		             $output.=$this->addnewCarburant();	  
              }	
			
			$output.=$this->renderCarburantList();
	    }
		
				  elseif (Tools::isSubmit('viewCarosses')  || Tools::isSubmit('submitAddnewCarosse'))
		{
			if(Tools::isSubmit('submitAddnewCarosse')){
		            $output.= $this->addnewCarosse();	  
              }	
			
			$output.=$this->renderListCarosses();
	    }
		
		
		
		 elseif (Tools::isSubmit('ViewAssignData')  || Tools::isSubmit('SubmitSaveSelected')  )
		{
			$id_product=(int)Tools::getValue('id_product');
			
			if(Tools::isSubmit('SubmitSaveSelected')){
		            $output.= $this->assignData($id_product);	  
              }	
			
			$output.=$this->displaySelected($id_product);
	    }




       

       
		
		else
       {	
		   
		   	
        $output.='</br>'.$this->getSettings();		
	   }	
            return $output;
    } 
	
	 public function addMenu()
    {
        $nka_link=$this->context->link->getAdminLink('AdminModules', false);
        $this->smarty->assign([
            'admin_link'=>$nka_link,
            'token'=>Tools::getAdminTokenLite('AdminModules'),
            'module_name'=>$this->name,
        ]);

        return $this->display(__FILE__, 'views/templates/admin/top_menu.tpl');
    }
	
	
	public  function getSettings(){
		
		$html='<div  class="panel"> No  Settings Needed ! </div>';		
		
		return $html;
		
	}
	
	/* NEW   CODE */
	
	
	
	public  function  addnewCarburant(){
		
		 $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   $category_id=Tools::getValue('id_category');
	   
   if(Tools::isSubmit('submitAddnewCarburant')){    	 
		
        $FilterCarburant=new FilterCarburant();
		
        $FilterCarburant->name=Tools::getValue('carburantName');
        
        	
				
		
		 if(!$FilterCarburant->add()){			
			$message_alert=$this->displayError($this->l('All field are required.'));
        } else {
            
			$message_alert=$this->displayConfirmation($this->l('Your Carburant has been successfully added.'));
        }		
		
		
      }
	  
	  else{
		  if(Tools::isSubmit('submitAddnewCarburant')){
		  $message_alert=$this->displayError($this->l('All field are required.'));
		  }
	  }
	  
	  
	  return $message_alert;
	  
		
	}	
	
	
	public function renderCarburantList(){		
		$id_lang = (int)Context::getContext()->language->id;
    
	    
        $all_carburants=FilterCarburant::getAll();
		$all_models=FilterModels::getModels();	
		
	
    $this->context->smarty->assign(
      array(		  
          		  
          'all_carburants'=>$all_carburants,
		  'all_models'=>$all_models,                   		
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
       return $this->display(__FILE__, 'views/templates/admin/cars/view_carburants.tpl');
		
	}
	
	public  function  addnewCapacity(){
		
		   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   $category_id=Tools::getValue('id_category');
	   
   if(Tools::isSubmit('submitAddnewCapacity')  && Tools::getValue('id_carburant')!=''  && Tools::getValue('id_motor_volume')!=''){    	 
		
        $HightCapacity=new HightCapacity();
		
		
		$HightCapacity->name=Tools::getValue('capacity_name');	
        $HightCapacity->id_carburant=Tools::getValue('id_carburant');
        $HightCapacity->id_motor_volume=Tools::getValue('id_motor_volume');
        
		
		
				
		
		 if(!$HightCapacity->add()){			
			$message_alert=$this->displayError($this->l('All field are required.'));
        } else {
            
			$message_alert=$this->displayConfirmation($this->l('Your Capacity has been successfully added.'));
        }		
		
		
      }
	  
	  else{
		  if(Tools::isSubmit('submitAddnewCapacity')){
		  $message_alert=$this->displayError($this->l('All field are required.'));
		  }
	  }
	  
	  
	  return $message_alert;
	  
		
	}
	
	
	public function renderListCapacities(){
		
		$id_lang = (int)Context::getContext()->language->id;
    
	    $category_id=(int)Tools::getValue('id');
        $all_marques=FilterMarques::getMarques();
		$all_volumes=MotorVolume::getAll();
		$all_carburants=FilterCarburant::getAll();
		
		$categories=Filter::getAllCategories($id_lang);
		
		$all_capacities=HightCapacity::getAll();
	
    $this->context->smarty->assign(
      array(		  
          'categories'=>$categories,			  
          'all_marques'=>$all_marques,
		  'all_volumes'=>$all_volumes,
		  'all_carburants'=>$all_carburants,
          'all_capacities'=>$all_capacities,          
          'category_id'=>$category_id,		
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'views/templates/admin/view_capacities.tpl');
		
	}
	
   
   public  function  addnewCarosse(){
		
		   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   $category_id=Tools::getValue('id_category');
	   
   if(Tools::isSubmit('submitAddnewCarosse')  && Tools::getValue('id_carburant')!=''  && Tools::getValue('id_motor_volume')!=''){    	 
		
        $FilterCarosse=new FilterCarosse();
		
		
		$FilterCarosse->name=Tools::getValue('carrose_name');	
        $FilterCarosse->id_carburant=Tools::getValue('id_carburant');
        $FilterCarosse->id_motor_volume=Tools::getValue('id_motor_volume');
		$FilterCarosse->id_hight_capacity=Tools::getValue('id_hight_capacity');
        
		
		
				
		
		 if(!$FilterCarosse->add()){			
			$message_alert=$this->displayError($this->l('All field are required.'));
        } else {
            
			$message_alert=$this->displayConfirmation($this->l('Your Carosse has been successfully added.'));
        }		
		
		
      }
	  
	  else{
		  if(Tools::isSubmit('submitAddnewCarosse')){
		  $message_alert=$this->displayError($this->l('All field are required.'));
		  }
	  }
	  
	  
	  return $message_alert;
	  
		
	}
	
	
	public function renderListCarosses(){
		
		$id_lang = (int)Context::getContext()->language->id;
    
	    $category_id=(int)Tools::getValue('id');
        $all_marques=FilterMarques::getMarques();
		$all_volumes=MotorVolume::getAll();
		$all_carburants=FilterCarburant::getAll();
		
		$categories=Filter::getAllCategories($id_lang);
		
		$all_capacities=HightCapacity::getAll();
		
		$all_carosses=FilterCarosse::getAll();
	
    $this->context->smarty->assign(
      array(		  
          'categories'=>$categories,			  
          'all_marques'=>$all_marques,
		  'all_volumes'=>$all_volumes,
		  'all_carburants'=>$all_carburants,
          'all_capacities'=>$all_capacities,
          'all_carosses'=>$all_carosses,         
          'category_id'=>$category_id,		
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'views/templates/admin/view_carrosses.tpl');
		
	}
   
   
   
     public function addnewMake(){	
	   
	   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   /*$category_id=Tools::getValue('id_category');*/
	   $category_id=1;
	   
     if(Tools::isSubmit('submitAddnewMake')){    	 
		
        $FilterMarques=new FilterMarques();       
		
		$FilterMarques->marque_name=Tools::getValue('marque_name');
		$FilterMarques->more_infos=Tools::getValue('more_infos');
		$Quiz_name=$FilterMarques->marque_name;
		$FilterMarques->category_id=$category_id;
		$FilterMarques->id_lang=$id_lang;
		
		
				
		
		 if(!$FilterMarques->add()){			
			$message_alert=$this->displayError($this->l('All field are required.'));
        } else {
            
			$message_alert=$this->displayConfirmation($this->l('Your Make has been successfully added.'));
        }		
		
		
      }
	  
	  
	  return $message_alert;
	  
	  
   } 

        /*  END  OF NEW  CODE   */
	
	
// list
      	public function renderList()
	{
		$fields_list = array(
		
		   'id' => array(
				'title' => $this->l('ID Filter'),
				'search' => false,
			),
			'category_name' => array(
				'title' => $this->l('Category Name'),
				'search' => false,
			)				
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('Filter: Last added categories');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id';
		$helper_list->table = 'nsfilter_categories';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		$helper_list->actions = array('view','edit','delete');
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		// This is needed for displayEnableLink to avoid code duplication
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$id_lang = (int)Context::getContext()->language->id; 
		$order=new Filter();
		$orders=$order->getAllCategories($id_lang);
		$helper_list->listTotal = count($order->getAllCategories($id_lang));

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}
  
  	public function renderAddNewCategoryForm()
	{  
	  
	 $language_list=Language::getLanguages(true, (int)$this->context->shop->id); 
	  
    $this->context->smarty->assign(
      array(	         		  
		  'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
		  'message_alert'=>$this->addnewCategory(),
          'language_list'=>$language_list,		  
            )
         );   
	  
		return $this->display(__FILE__, 'submitAddnewCategory.tpl');
	}
	
	public function getConfigFieldsValues()
	{
		return array(
			'innova_card_number_chiffre' => Tools::getValue('innova_card_number_chiffre', Configuration::get('innova_card_number_chiffre')),
			
		);
	} 
  
  //end adding vouchers  
  
   public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
		if(count($orders) > $pagination)
			$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

		return $orders;
	}  
  

//list	
  
  
   public function hookDisplayNav($params)
	{
		return '';
	}
	
	
	public function hookDisplayTopColumn($params)
	{
		return '';
	}
	
	
	public function hookDisplayTop($params)
	{
		return $this->hookTop($params);
	}
	
	
	
  
    
    public function hookTop($params)
    {
        
		
		$this->context->smarty->assign(
           array(          
              'search_link' => $this->context->link->getModuleLink('ns_carfilter', 'search'), 
              'all_makes' =>FilterMarques::getMarques(),
              'module_path'=>$this->getPath(), 			  
                )
               ); 
			  
         
       return $this->display(__FILE__, 'nav_pop_up.tpl'); 
	   
    }
	
	
		
	 public function displaySelected($id_product)
  {		
		
		 $id_marque=(int)Tools::getValue('id_marque')?(int)Tools::getValue('id_marque'):'';	
        $id_model=(int)Tools::getValue('id_model')?(int)Tools::getValue('id_model'):'';		
		$id_type=(int)Tools::getValue('id_type')?(int)Tools::getValue('id_type'):'';	
		$id_carburant=(int)Tools::getValue('id_carburant')?(int)Tools::getValue('id_carburant'):'';
		$id_motor_volume=(int)Tools::getValue('id_motor_volume')?(int)Tools::getValue('id_motor_volume'):'';
		$id_hight_capacity=(int)Tools::getValue('id_hight_capacity')?(int)Tools::getValue('id_hight_capacity'):'';
		$id_carosse=(int)Tools::getValue('id_carosse')?(int)Tools::getValue('id_carosse'):'';
		$year_from=Tools::getValue('year_from')?(int)Tools::getValue('year_from'):'';
		$year_to=Tools::getValue('year_to')?(int)Tools::getValue('year_to'):'';
		
		
		
		$year_start=2000;
		$year_second_start=Tools::getValue('year_from');

       $all_models=FilterModels::getModelsByIdMake($id_marque);		
	  /*$all_models=FilterOils::getModelsByIdMake($id_marque);*/

     	$iso_code=Context::getContext()->language->iso_code;  
		
		$base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 
		
		$token=Tools::getAdminTokenLite('AdminModules');
		$nka_display_link='index.php?controller=AdminModules&configure=ns_carfilter&id_product='.$id_product.'&ViewAssignData&token='.$token;
		$result_submit_link=$nka_display_link;
		
		
		$product=new Product($id_product);
		
		$this->context->smarty->assign(array(			
		'nka_display_link' =>$nka_display_link,
		'result_submit_link'=>$result_submit_link,    
        'all_models'=> $all_models,
        'all_makes' =>FilterMarques::getMarques(),      
	  'id_marque'=>$id_marque,
      'id_model'=>$id_model,     
	  'id_carburant'=>$id_carburant,
	  'id_motor_volume'=>$id_motor_volume,
	  'id_hight_capacity'=>$id_hight_capacity,
	  'id_carosse'=>$id_carosse,	  
	  'id_lang'=>Context::getContext()->language->id,
	  'iso_code'=>$iso_code,
	  'all_model_carburants'=>FilterCarburant::getAll(),
	  'all_motor_volumes'=>MotorVolume::getByIdCarburant($id_carburant),
	  'all_hight_capacities'=>HightCapacity::getByIdVolume($id_motor_volume),
	  'all_carosses'=>FilterCarosse::getByIdCapacity($id_hight_capacity),
	  'all_years_start'=>FilterCarYear::getAll($year_start),
	  'all_years_to'=>FilterCarYear::getAll($year_second_start),
	  'year_from'=>$year_from,
	  'year_to'=>$year_to,
	  'id_product'=>$id_product,
	  'product'=>$product,
      'token'=>$token,
      'base_dir_nka'=>$base_dir_nka,
	  'product_link'=>$this->context->link->getProductLink($product),
       	  
        
	));
	
	
	  return $this->display(__FILE__, 'views/templates/admin/display_selected.tpl');
  }
  
  
  public  function assignData($id_product){	  
  
     $message='';
  
      if(Tools::isSubmit('SubmitSaveSelected') &&  !empty($id_product)){
	      
        $sampleObj = FilterProduct::loadByIdProduct($id_product);        
        $sampleObj->id_product = $id_product;
		$sampleObj->id_marque= Tools::getValue('id_marque')?Tools::getValue('id_marque'): $sampleObj->id_marque;
        $sampleObj->id_model= Tools::getValue('id_model')?Tools::getValue('id_model'):$sampleObj->id_model;
        $sampleObj->id_carburant= Tools::getValue('id_carburant')?Tools::getValue('id_carburant'):$sampleObj->id_carburant;
        $sampleObj->id_motor_volume= Tools::getValue('id_motor_volume')?Tools::getValue('id_motor_volume'):$sampleObj->id_motor_volume;
        $sampleObj->id_hight_capacity=Tools::getValue('id_hight_capacity')?Tools::getValue('id_hight_capacity'):$sampleObj->id_hight_capacity;
        $sampleObj->id_carosse=1;  //Tools::getValue('id_carosse')?Tools::getValue('id_carosse'):$sampleObj->id_carosse;
        $sampleObj->year_from= Tools::getValue('year_from')?Tools::getValue('year_from'):$sampleObj->year_from;
        $sampleObj->year_to= Tools::getValue('year_from')?Tools::getValue('year_from'):$sampleObj->year_to;
        
        if(!empty($sampleObj) && isset($sampleObj->id)){
            $sampleObj->update();
			$message=$this->displayConfirmation($this->l('Data  updated Successfully.'));
        } else {
            $sampleObj->add();
			$message=$this->displayConfirmation($this->l('Data  added Successfully.'));
        }
		
      }
	  
	  
	  return  $message;
	  
  }
	
	
	    public function hookDisplayAdminProductsExtra($params) {
        $id_product = _PS_VERSION_ < '1.7' ? (int) Tools::getValue('id_product') : (int) $params['id_product'];
        $sampleObj = FilterProduct::loadByIdProduct($id_product);
        if(!empty($sampleObj) && isset($sampleObj->id)){
            $this->context->smarty->assign(array(
                'sampleObj' => $sampleObj,
            ));
        }
		
		$module_path=_PS_MODULE_DIR_.$this->name;
		
		 $this->context->smarty->assign(array(			
				'id_product'=>$id_product,
				'token'=>Tools::getAdminTokenLite('AdminModules'),				
				
            ));
		
		
        
        return $this->display(__FILE__, 'views/templates/admin/cars/sample_admin.tpl');
    }
    
    public function hookActionProductUpdate($params) {
        $id_product = _PS_VERSION_ < '1.7' ? (int) Tools::getValue('id_product') : (int) $params['id_product']; 
       return '';		
    }
    
    public function hookDisplayFooterProduct($params) {
        $id_product = Tools::getValue('id_product');
        $sampleObj = FilterProduct::loadByIdProduct($id_product);
        if(!empty($sampleObj) && isset($sampleObj->id)){
            $this->context->smarty->assign(array(
                'sampleObj' => $sampleObj,
            ));
        }
        
        return $this->display(__FILE__, 'views/templates/frontend/footer_product.tpl');
    }
    
	
	 public function hookAdminOrder($params)
	{
	  
	  
	  $id_order=(int)Tools::getValue('id_order');
	  $order=new Order($id_order);
	  $id_customer=$order->id_customer;
	  $id_cart=$order->id_cart;
	
      $this->context->smarty->assign(
      array(		  	  
          'update_token'=>Tools::getAdminTokenLite('AdminModules'),
          'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
          'order_products'=>$order->getProducts(),          
            )
            );   


     return $this->display(__FILE__, 'order_details.tpl'); 	  
	 
	
	}
	
	
	
		public function hookShoppingCart($params)
	{
	  		
		
		$id_customer=($this->context->customer->logged ? $this->context->customer->id: false);
	    $context = Context::getContext();
	    $id_cart=$context->cookie->id_cart;
	    $cart=new Cart($id_cart); 

        $products = $params['cart']->getProducts(false);		
		$this->smarty->assign(array(			
			'cart_products'=>$products,
		));		
		
		return $this->display(__FILE__, 'shopping_cart.tpl');
	
	}	
   
   
    
    public function hookDisplayHeader()
   {
       	/*
        $this->context->controller->addCSS($this->_path.'css/pop_up.css', 'all');	
        $this->context->controller->addCSS($this->_path.'css/style.css', 'all');			
		*/
    }  	
	
	public function getPath(){
		
		return $this->_path;
		
	}
	
	//adding new Filter category
	   public function addnewCategory(){	
	   
	   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   
     if(Tools::isSubmit('submitAddnewCategory')){         	 
		
        $QuizCat =new Filter();
        
		$QuizCat->category_name=Tools::getValue('category_name');
		$QuizCat->id_lang=(int)Tools::getValue('id_lang');
		$Quiz_chiffre=$QuizCat->category_name;
		
		if(Filter::verifyByName($Quiz_chiffre) !=''){
         $message_alert='Please remember duplicated Categories name are not allowed.';
   }	
		
            elseif(!$QuizCat->add()){$messaege_alert="An error has occurred: Can\'t save the current object";	}
       else{
            			
		
        $message_alert="Your Category has been successfully added.";	
		
		
		}	
		
      }
	  return $message_alert;
	  
	  
   }  
    
   
   public function displayLinkFront(){
   
   $id_customer=($this->context->customer->logged ? $this->context->customer->id: false);
	$Filter=new Filter();  
   
   $this->context->smarty->assign(
      array(	      
		  'intro_text'=>Configuration::get('DEFAULT_PROD_ID'),          
		  'voucher'=>$Filter, 
          'my_voucher_list_link' => $this->context->link->getModuleLink('ns_carfilter', 'display'),
          'search_link' => $this->context->link->getModuleLink('ns_carfilter', 'search') 	 		  
          
            )
               );  	 
         
       return $this->display(__FILE__, 'displayLinkFront.tpl'); 
   
   }
   
     public function renderCategoryItems(){  
	    
		$id_lang = (int)Context::getContext()->language->id;
    
	    $category_id=(int)Tools::getValue('id');
        $all_marques=FilterMarques::getMarques();
		
		$categories=Filter::getAllCategories($id_lang);
		
		$language_list=Language::getLanguages(true, (int)$this->context->shop->id);
	
    $this->context->smarty->assign(
      array(		  
          'categories'=>$categories,			  
          'all_marques'=>$all_marques,           
          'category_id'=>$category_id,	
          'language_list'=>$language_list,		  
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'views/templates/admin/view_makes.tpl');
  }
  
  
     /*  Add new  Models **/
  
  public   function renderModelItems(){
	  
	  $id_lang = (int)Context::getContext()->language->id;
    
	    $category_id=(int)Tools::getValue('id');
        $all_marques=FilterMarques::getMarques();
		$all_models=FilterModels::getModels();
		
		$categories=Filter::getAllCategories($id_lang);
	    $language_list=Language::getLanguages(true, (int)$this->context->shop->id); 


    $this->context->smarty->assign(
      array(		  
          'categories'=>$categories,			  
          'all_models'=>$all_models, 
          'all_marques'=>$all_marques, 		  
          'new_model'=>$this->addnewModel(),
          'category_id'=>$category_id,	
          'language_list'=>$language_list, 		  
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'views/templates/admin/view_models.tpl');
	  
  }
  
  public function addnewModel(){	
	   
	   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   $id_marque=(int)Tools::getValue('id_marque');
	   
     if(Tools::isSubmit('submitAddnewModel') && !empty($id_marque)){    	 
		
        $FilterModels=new FilterModels();        
		
		$FilterModels->model_name=Tools::getValue('model_name');
		$FilterModels->id_marque=$id_marque;		
		$FilterModels->id_lang=$id_lang;
		
		
			
		
		 if(!$FilterModels->add()){            
			$message_alert=$this->displayError($this->l('Error can not add Model.'));
        } else {			
			$message_alert=$this->displayConfirmation($this->l('Your Model has been successfully added.'));
        }		
		
		
      }
	  
   return $message_alert;
	  
	  
   }    

  
  /*   end  of  Models **/
  
  
  /*   add new Type **/
  
   public function renderVolumeItems(){
	   
	   
	  $id_lang = (int)Context::getContext()->language->id;
    
	    $category_id=(int)Tools::getValue('id');
        $all_volumes=MotorVolume::getAll();
		$all_carburants=FilterCarburant::getAll();
		
	    $language_list=Language::getLanguages(true, (int)$this->context->shop->id); 
	
	
    $this->context->smarty->assign(
      array(          		  
          'all_carburants'=>$all_carburants, 
          'all_volumes'=>$all_volumes,          
          'category_id'=>$category_id,	
         'language_list'=>$language_list,			  
          'url_submit_add'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'views/templates/admin/cars/view_volumes.tpl');
	  
  }
  
  
   public function addnewVolume(){	
	   
	   $message_alert='';
	   
	   $id_lang=(int)Context::getContext()->language->id; 
	   $id_carburant=(int)Tools::getValue('id_carburant');
	   
     if(Tools::isSubmit('submitAddnewVolume') && !empty($id_carburant)){    	 
		
        $MotorVolume=new MotorVolume();        
		
		$MotorVolume->name=Tools::getValue('VolumeName');
		$MotorVolume->id_carburant=$id_carburant;		
		
		
		
			
		
		 if(!$MotorVolume->add()){            
			$message_alert=$this->displayError($this->l('Error can not add Volume.'));
        } else {			
			$message_alert=$this->displayConfirmation($this->l('Your Volume has been successfully added.'));
        }		
		
		
      }
	  
   return $message_alert;
	  
	  
   }    
  
  
  
  
  /*  end  of  add new type **/
  
  
   
  public function  renderUpdate(){  
  
        $category_id=(int)Tools::getValue('id');
        $QuizCat=new Filter($category_id);
		$category_name=Tools::getValue('category_name');
  if(Tools::isSubmit('submitUpdateCategory') && !empty($category_id) && !empty($category_name)){
        
		$QuizCat->category_name=$category_name;        	
	   $QuizCat->update();
  } 
       	
	   
    $this->context->smarty->assign(
      array(	      
		  'category_id'=>$category_id,
          'quiz_cat'=>$QuizCat,	
          'mod_name'=>$this->name,		  
          'update_token'=>Tools::getAdminTokenLite('AdminModules'),
          'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')          
            )
            );  
   
    return $this->display(__FILE__, 'edit_category.tpl');
	
   }
    
  
  
  //for employee email 
  
  	   public function displayForm()
  {
    // Get default language
	 $productObj = new Product();
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	$id_shop=Context::getContext()->shop->id;;
	$id_lang=(int)Context::getContext()->language->id; 
    $products = $productObj -> getProducts($id_lang, 0, 0, 'id_product', 'DESC' );
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Settings'),
			'icon' => 'icon-cogs'
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('Default product id is:'),
                'name' => 'DEFAULT_PROD_ID',
                'size' => 20,
                'required' => true,
				'desc' => $this->l('Select a value bellow if you wish to change it.')
            ),			
			array(
					'type' => 'select',
					'label' => $this->l('Select a Product'),
					'name' => 'id_product',
					
					'options' => array(
						'query' =>$products,
						'id' => 'id_product',
						'name' => 'name'
						
					),
					'desc' => $this->l('Select the Product  you want to redirect to after success.')
                      ),	
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    // Load current value
    $helper->fields_value['DEFAULT_PROD_ID'] = Configuration::get('DEFAULT_PROD_ID');
	$helper->fields_value['id_product'] =Tools::getValue('id_product');
     
    return $helper->generateForm($fields_form);
    } 
  
  	
  public   function getImageID($id_product){	  
	  
	  $id_lang = (int)Context::getContext()->language->id;
	  
	  $product=new Product((int)$id_product);
	  $cover=Product::getCover((int)$id_product);
	  
	  if ($cover['id_image']!=''){
	  $src=$cover['id_image'];
	  
	  } 
	  else{
		  $src=null;
	  }
	  
	  return $src;
	  
  }	
   
   
   
  
  
  }

