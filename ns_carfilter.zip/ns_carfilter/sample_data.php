<?php
include_once('./../../config/config.inc.php');
include_once('./../../init.php');
//require_once(dirname(__FILE__) . '/classes/FilterOils.php');  

include_once(dirname(__FILE__).'/ns_carfilter.php');

$id_marque=$_REQUEST['id_marque'];

echo 'ID :'.$id_marque;

/*
$currency =Context::getContext()->currency;
$id_marque=$_REQUEST['id_marque'];
       
$all_models=FilterOils::getModelsByIdMake($id_marque);	   

if(!empty($all_models))	
{ 

   echo  print_r($all_models);

}

Context::getContext()->smarty->assign(array(
            'search_Total' => 0,
            'searchResults' => null,
            'limit_item' => Configuration::get('NUM_ITEM_DISPLAY'),
            'query' => $search_string,
            'link' => Context::getContext()->link
        ));
*/

$otlivesearch = new ns_carfilter();

echo $otlivesearch->display(dirname(__FILE__).'/ns_carfilter.php', 'test.tpl');
