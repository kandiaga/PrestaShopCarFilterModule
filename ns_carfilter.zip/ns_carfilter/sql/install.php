<?php

$sql = array();

$sql[] ='CREATE TABLE IF NOT EXISTS `'. _DB_PREFIX_ .'nsfilter_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `id_lang` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';




$sql[] ='CREATE TABLE IF NOT EXISTS  `'. _DB_PREFIX_ .'nsfilter_marques` (
  `id_marque` int(11) NOT NULL AUTO_INCREMENT,
  `marque_name` text NOT NULL,  
  `category_id` int(11) NOT NULL DEFAULT 1,
  `id_lang` int(11) NOT NULL DEFAULT 1,
   `more_infos` text NULL, 
  PRIMARY KEY (`id_marque`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';

$sql[] ='CREATE TABLE IF NOT EXISTS  `'. _DB_PREFIX_ .'nsfilter_models` (
  `id_model` int(11) NOT NULL AUTO_INCREMENT,
  `model_name` text NOT NULL,  
  `id_marque` int(11) NOT NULL DEFAULT 1,
  `id_lang` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_model`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';




$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_types` (
  `id_type` int(11) NOT NULL  AUTO_INCREMENT,
  `type_name` text NOT NULL,  
  `id_model` int(11) NOT NULL DEFAULT 1,
  `id_lang` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_type`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';



$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_oils` (
  `id_oil` int(11) NOT NULL AUTO_INCREMENT,  
  `id_lang` int(11) NOT NULL DEFAULT 1,  
  `make`   varchar(250) NOT NULL,
  `model` varchar(250) NOT NULL,	
  `type` varchar(250) NOT NULL,	
  `componentName` varchar(250) NOT NULL,	
  `componentCode` varchar(250) NOT NULL,	
  `capacities` varchar(250) NOT NULL,	
  `DryCapacityBottles` varchar(250) NOT NULL,
  `SmallBottleRef` varchar(250) NOT NULL,	
  `GallonBottleReference` varchar(250) NOT NULL,	
  `OilDesignation` varchar(250) NOT NULL,	
  `OilLinkSmallBottle` varchar(250) NOT NULL,	
  `OilLinkGallonBottle` varchar(250) NOT NULL,
  PRIMARY KEY (`id_oil`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';





$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_oiltype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Type` text NOT NULL, 
  `TypeID` int(11) NOT NULL,  
  `id_lang` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_oilmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Model` text NOT NULL, 
  `ModelID` int(11) NOT NULL,  
  `id_lang` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';




$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_components` (
  `Components_ID` int(11) NOT NULL,   
  `en` text,
  `fr` text,
  `es` text,	  
  `pt` text,	
  `de` text,  
  PRIMARY KEY (`Components_ID`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_drycapacity` (
  `DryCapacity_ID` int(11) NOT NULL,   
  `en` text,
  `fr` text,
  `es` text,	  
  `pt` text,	
  `de` text,  
  PRIMARY KEY (`DryCapacity_ID`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


/*    new  Data  */

$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_carburant` (
  `id_carburant` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,  
  PRIMARY KEY (`id_carburant`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_motor_volume` (
  `id_motor_volume` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,  
  `id_carburant` int(11) NOT NULL DEFAULT 1,  
  PRIMARY KEY (`id_motor_volume`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_hight_capacity` (
  `id_hight_capacity` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,  
  `id_carburant` int(11) NOT NULL DEFAULT 1,
  `id_motor_volume` int(11) NOT NULL DEFAULT 1,   
  PRIMARY KEY (`id_hight_capacity`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_carosse` (
  `id_carosse` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,  
  `id_carburant` int(11) NOT NULL DEFAULT 1,
  `id_motor_volume` int(11) NOT NULL DEFAULT 1, 
   `id_hight_capacity` int(11) NOT NULL DEFAULT 1,   
  PRIMARY KEY (`id_carosse`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';



$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,  
  PRIMARY KEY (`id`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';




$sql[] ='CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'nsfilter_product` (
  `id_nsfilter_product` int(11) NOT NULL AUTO_INCREMENT, 
  `id_product` int(11) NOT NULL ,  
  `id_marque` int(11) NOT NULL DEFAULT 1,  
  `id_model`   int(11) NOT NULL,
  `id_carburant` int(11) NOT NULL,	
  `id_motor_volume` int(11) NOT NULL,	
  `id_hight_capacity` int(11) NOT NULL,	
  `id_carosse` int(11) NOT NULL,	
  `year_from` varchar(250) NOT NULL,	
  `year_to` varchar(250) NOT NULL,  
  PRIMARY KEY (`id_nsfilter_product`),
  UNIQUE  `FILTER_PROD_UNIQ` (  `id_product` )
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';

