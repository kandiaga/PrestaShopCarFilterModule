<?php
$sql = array();

$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_categories`';
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_oils`';
/*$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_marques`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_models`'; */
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_types`'; 
/*  new  tables*/


$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_carburant`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_motor_volume`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_hight_capacity`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_carosse`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_year`'; 
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'nsfilter_product`'; 




?>
